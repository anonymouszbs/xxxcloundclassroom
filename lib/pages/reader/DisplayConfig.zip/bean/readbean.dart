

class ReadBookBean{
String? workPermitNum;
String? name;
String? bookname;

}