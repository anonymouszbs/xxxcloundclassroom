
import 'dart:typed_data';


import 'package:epub_view/epub_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:xxxcloundclassroom/pages/reader/DisplayPage.dart';
import 'package:xxxcloundclassroom/pages/reader/controller/readercontroller.dart';

import 'DisplayConfig.dart';
import 'PageBreaker.dart';

class ReaderBookPage extends StatefulWidget {
  final dirPath;
  const ReaderBookPage({Key? key, this.dirPath}) : super(key: key);

  @override
  State<ReaderBookPage> createState() => _ReaderBookPageState();
}

class _ReaderBookPageState extends State<ReaderBookPage>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  late List<EpubChapter> epubBook;
  late DisplayConfig config;
  var size = Size(ScreenUtil().screenWidth, ScreenUtil().screenHeight);
  List<YDPage> page = [];
  late Widget widget1;
  int statescode = 12;//状态吗 12loading 13sucess
  @override
  void initState() {
    config = DisplayConfig.getDefault();
    ReaderController.current.size = Size(ScreenUtil().screenWidth, ScreenUtil().screenHeight);
    initcontent();
    super.initState();
  }
  @override
  void dispose(){
    ReaderController.current.closeAppbar();
    super.dispose();
  }

  Future<Uint8List> _loadFromAssets(String assetName) async {
    final bytes = await rootBundle.load(assetName);
    return bytes.buffer.asUint8List();
  }

//正文的样式
  TextSpan _generateContentTextSpan(String chapterContent){
    final textStyle = TextStyle(
      color: Color(config.textColor),
      fontSize: config.textSize,
      fontWeight: config.isTextBold==1?FontWeight.bold:FontWeight.normal,
      fontFamily: config.fontPath,
      height: config.lineSpace,
    );

    final textSpan = TextSpan(
      text: chapterContent,
      style: textStyle,
    );
    return textSpan;
  }

  //标题的样式
  TextSpan _generateTitleTextSpan(String title){
    final titleStyle = TextStyle(
        color: Color(config.titleColor),
        fontSize: config.titleSize,
        fontWeight: config.isTitleBold==1?FontWeight.bold:FontWeight.normal,
        fontFamily: config.fontPath,
    );
    final titleSpan = TextSpan(
      text: title.trim(),
      style: titleStyle,
    );
    return titleSpan;
  }

  //计算分页的大小
  Size _generateTextPageSize(){
    var textPageSize = Size(size.width- config.marginLeft - config.marginRight, size.height - config.marginTop - config.marginBottom);//显示区域减去外边距
    if(config.isSinglePage == 1){//单页
      return textPageSize;
    }else{//双页
      return Size((textPageSize.width-config.inSizeMargin)/2,textPageSize.height);
    }
  }

  initcontent() async {
    EpubBook epub  = await  EpubReader.readBook(_loadFromAssets("img/hafo.epub"));
    epubBook = epub.Chapters!;
    

   ReaderController.current.initcode(p: epubBook);

    if (ReaderController.current.dh != true) {
      AnimationController animationController = AnimationController(
          vsync: this, duration: const Duration(milliseconds: 400));
      AnimationController animationController1 = AnimationController(
          vsync: this, duration: const Duration(milliseconds: 400));
      AnimationController animationController2 = AnimationController(
          vsync: this, duration: const Duration(milliseconds: 400));
      ReaderController.current.leftUIanimationController = animationController2;   
      ReaderController.current.topUIanimationController = animationController;
      ReaderController.current.bottomUIanimationController =
          animationController1;
    }
    setState(() {
      statescode = 13;
    });
  }

  
///监听滑动手势
///
    

void _onHorizontalDragUpdate(DragUpdateDetails details) {
    if (details.delta.dx > 0) {
      print("right");
      //right;
    } else if (details.delta.dx < 0) {
      //left
    }
  }



   

     
//内容净化
  String _formatContent(String chapterContent){
    var result = chapterContent;
    // print(result);
    //净化连续换行为一个换行
    result = result.replaceAll(RegExp(r'[ \n]*\n+[ ]?'), '\n');
    //太长的空格替换成两个
    result = result.replaceAll(RegExp(r'[ ]{4,}'), '  ');
    //内容中每个段落开头的空格
    var spaceForParagraph = ' ' * config.spaceParagraph;
    //段落间空行
    var lineSpace = config.paragraphSpace?'\n':'';
    result = spaceForParagraph + result.replaceAll('\n', '\n$lineSpace$spaceForParagraph');


    return result;
  }

  ///取出p标签的内容
  regCode(htmlcontent) {
    String html = htmlcontent;
    String? pTagContent = "";
    RegExp exp = RegExp(r'<p>(.*?)</p>');
    Iterable<Match> matches = exp.allMatches(html);
    for (Match match in matches) {
      if (match.group(1) != null) {
        pTagContent = "${pTagContent!}${match.group(1)}\n";
      }
    }
    return pTagContent!.replaceAll("\n", "\n");
  }

  List height = [];
  int a = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        body: OrientationBuilder(builder: ((context, orientation) {
              if(size.width!=ScreenUtil().screenWidth){
                size = Size(ScreenUtil().screenWidth, ScreenUtil().screenHeight);
                initcontent();
              }
          
         return GestureDetector(
          onHorizontalDragUpdate: _onHorizontalDragUpdate,
            onTap: () {
              print("太强了");
              ReaderController.current.initstate(context);
               ReaderController.current.leftUIisopen == true
          ?  ReaderController.current.leftUIanimationController.animateTo(0)
          :  ReaderController.current.leftUIanimationController.animateTo(0);
           ReaderController.current.leftUIisopen = false;
            },
            child: Stack(children: [
           statescode==13 ?PageView.custom(
                physics:NeverScrollableScrollPhysics(),
                scrollDirection: config.isVertical==1?Axis.vertical:Axis.horizontal,
                pageSnapping: config.isVertical != 1,
                childrenDelegate: SliverChildBuilderDelegate((ctx,index){
                  return Obx(()=>ReaderController.current.chapaterpage[index]);
                }, childCount: 99999999),
                controller:ReaderController.current.pageviewcontroller,
                onPageChanged: (i){
                  Future.delayed(Duration(milliseconds: 100),(){
                    ReaderController.current.listenScrollPage(i);
                  });
                 
                },
              ):Container(),

              Row(
                children: [
                  Expanded(child: InkWell(onTap: (){
                    ReaderController.current.pageviewcontroller.previousPage(duration:Duration(milliseconds: 200), curve: Curves.easeInSine);
                  },)),
                  SizedBox(width: ScreenUtil().screenWidth*0.8,),
                  Expanded(child: InkWell(onTap: (){
                     ReaderController.current.pageviewcontroller.nextPage(duration:Duration(milliseconds: 200), curve: Curves.easeInSine);
                  },))
                ],
              )


            ],),
        );
        })
             
    ));    
  }

  @override
  bool get wantKeepAlive => false;
}
