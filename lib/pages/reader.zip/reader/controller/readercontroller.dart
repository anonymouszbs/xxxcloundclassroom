import 'dart:async';
import 'dart:developer';

import 'package:epub_view/epub_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:path/path.dart';
import 'package:xxxcloundclassroom/compents/common_widgets.dart';
import 'package:xxxcloundclassroom/config/dataconfig/globalvar_config.dart';
import 'package:xxxcloundclassroom/pages/reader/DisplayConfig.dart';
import 'package:xxxcloundclassroom/pages/reader/PageBreaker.dart';

import '../../../compents/animations.dart';
import '../DisplayPage.dart';
import '../textUtils.dart';

class ReaderController extends GetxController {
  static ReaderController get current => Get.find<ReaderController>();
  bool topUIisopen = false, bottomUIisopen = false, leftUIisopen = false;
  bool _topUIopen = false, _bottomUIopen = false, _leftUIopen = false;
  late OverlayEntry topUIoverlayEntry, bottomUIoverlayEntry, leftUIoverlayEntry;
  late AnimationController topUIanimationController;
  late AnimationController bottomUIanimationController;
  late AnimationController leftUIanimationController;
  late PageController pageviewcontroller = PageController(initialPage: 0);

  bool dh = false;
  Rx<double> fontsize = 14.0.obs;
  DisplayConfig config = DisplayConfig.getDefault();
  //初始化章节
  List<EpubChapter> ebookchaps = [];
  RxList chapaterpage = [].obs;
  RxBool opage = true.obs;
  //初始化动画
  int chapaterindex = 0; //
  int pageindex = 0; //这个才是章节index
  int currentindex = 0; //现行选中页 index
  //初始化大小
  Size size = Size(320, 480);

  RxInt currentpageindex = 0.obs;
  List pages = [];
  List ydpages = [];
  List chapaters = [];
  int time = 3000;
  RxString title = "".obs;
  RxBool scrolltrue = false.obs;

  List itemschatgpt = [];

  ///记录哪本书看过的章节
  notesReadchapt(keys) {}

  ///查询是否看过这个章节()
  findchapt(keys) {}
  //翻页监听，看到哪个章节 大帅哥
  listenScrollPage(index) {
    currentindex = index;
    if (config.isSinglePage == 2 || config.isSinglePage == 1) {
      for (var i = 0; i < pages.length; i++) {
        Map<int, int> map = pages[i];
        int keys = int.parse(
            map.keys.toString().replaceAll("(", "").replaceAll(")", ""));
        int values = int.parse(
            map.values.toString().replaceAll("(", "").replaceAll(")", ""));
        if (index <= values) {
          if (index == values) {
            notesReadchapt(keys);
          }
          pageindex = keys;
          print(pageindex.toString()+"哈哈");
          print(pages);
          print(ydpages);
          title.value = ebookchaps[keys].Title!;
          int jindex1 = int.parse(ydpages[i]
              .values
              .toString()
              .replaceAll("(", "")
              .replaceAll(")", ""));
         
          int jindex = jindex1 - (values - index as int) - 1;
print(chapaters);
        print((jindex==0&&chapaters.contains(pageindex-1)==false));
          if(jindex-1<=0&&chapaters.contains(pageindex-1)==false){
            print("加载上一页");
            onLoadPrevious();
          }
          currentpageindex.value = jindex + 1;
          break;
        }
      }
    }

    if (chapaterpage.length - currentindex == 1) {
      onNext();
    }
    
  }

  ///  重新载入章节 比如修改字体等效果
  ///
  onLoadChapter() {
    List chapater = [];
    List page = [];
    List ydp = [];
    if (config.isSinglePage == 2) {
      pages.asMap().entries.map((e) {
        var j_chapterindex = e.key + 1;
        var content = regCode(
            ebookchaps[j_chapterindex].HtmlContent!); //通过章节id取内容并加到呢个啥你懂吧
        var pagebreaker = PageBreaker(
            generateContentTextSpan(content),
            generateTitleTextSpan(ebookchaps[j_chapterindex].Title!),
            generateTextPageSize(size));
        var ydpage = pagebreaker.splitPage();

        for (var i = 0; i < (ydpage.length / 2).ceil(); i++) {
          int doublepage = i * 2;
          chapater.add(Obx(() => DisplayPage(
                13,
                ydpage[doublepage],
                text2: doublepage > ydpage.length - 2
                    ? null
                    : ydpage[doublepage + 1],
                chapterIndex: 0,
                currPage: currentpageindex.value,
                maxPage: (ydpage.length / 2).ceil(),
                // viewPageIndex: chapaterindex +doublepage,
              )));
        }
        chapaters.clear();
        chapaters.add(pageindex);
        page.add({pageindex: chapater.length - 1}); //这个是已加载过的章节哟 并且到哪里
        ydp.add({pageindex: (ydpage.length / 2).ceil()}); // 每个章节包含多少页
        
        chapaterpage.value = chapater;
        pages = page;
        ydpages = ydp;
      }).toList();

      pageviewcontroller.animateToPage((currentindex / 2).ceil(),
          duration: Duration(milliseconds: 300), curve: Curves.ease);
    } else {
      pages.asMap().entries.map((e) {
        print("object");
        var j_chapterindex = e.key + 1;
        var content = regCode(
            ebookchaps[j_chapterindex].HtmlContent!); //通过章节id取内容并加到呢个啥你懂吧
        var pagebreaker = PageBreaker(
            generateContentTextSpan(content),
            generateTitleTextSpan(ebookchaps[j_chapterindex].Title!),
            generateTextPageSize(size));
        var ydpage = pagebreaker.splitPage();

        for (var i = 0; i < (ydpage.length).ceil(); i++) {
          int doublepage = i;
          chapater.add(Obx(() => DisplayPage(
                13,
                ydpage[doublepage],
                chapterIndex: 0,
                currPage: currentpageindex.value,
                maxPage: (ydpage.length).ceil(),
                // viewPageIndex: chapaterindex +doublepage,
              )));
        }

chapaters.clear();
        chapaters.add(pageindex);

        page.add({pageindex: chapater.length - 1}); //这个是已加载过的章节哟 并且到哪里
        ydp.add({pageindex: ydpage.length}); // 每个章节包含多少页
      
        chapaterpage.value = chapater;
        pages = page;
        ydpages = ydp;
      }).toList();
    }
  }

  ///加载上一章
  onLoadPrevious() {
   bool isloading  = false;
    if (pageindex == 0) {
      print("返回了");
      return;
    }

 print("返回了");

      var jpageindex = pageindex-1;

      var content = regCode(ebookchaps[jpageindex].HtmlContent!);
      var pagebreaker = PageBreaker(generateContentTextSpan(content),
          generateTitleTextSpan(ebookchaps[jpageindex].Title!), generateTextPageSize(size));
      var ydpage = pagebreaker.splitPage();
      if(ydpages.contains({jpageindex:ydpage.length})==false){
         if (config.isSinglePage == 1) {

        for (var i = ydpage.length; i > 0; i--) {
          chapaterpage.insert(0,Obx(() => DisplayPage(
                13,
                ydpage[i],
                chapterIndex: 0,
                currPage: currentpageindex.value,
                maxPage: ydpage.length,
                // viewPageIndex: chapaterindex +e,
              )));
        }
       
        pages.insert(0,{jpageindex: chapaterpage.length - 1});
        ydpages.insert(0,{jpageindex: (ydpage.length).ceil()});
        chapaters.insert(0,jpageindex);
        pageviewcontroller.jumpToPage(ydpage.length+2);
        
      } else {
        for (var i = 0; i < (ydpage.length / 2).ceil(); i++) {
          int doublepage = i * 2;
          chapaterpage.add(Obx(() => DisplayPage(
                13,
                ydpage[doublepage],
                text2: doublepage > ydpage.length - 2
                    ? null
                    : ydpage[doublepage + 1],
                chapterIndex: 0,
                currPage: currentpageindex.value,
                maxPage: (ydpage.length / 2).ceil(),
                // viewPageIndex: chapaterindex +doublepage,
              )));
        }
        pages.add({pageindex: chapaterpage.length - 1});
        ydpages.add({pageindex: ydpage.length});
        chapaters.add(pageindex);
      }

      };




     
    }
  

  onNext() {
    if (pageindex == ebookchaps.length) {
      return;
    }
    currentindex = 0;
    pageindex++;
    var content = regCode(ebookchaps[pageindex].HtmlContent!);
    var pagebreaker = PageBreaker(
        generateContentTextSpan(content),
        generateTitleTextSpan(ebookchaps[pageindex].Title!),
        generateTextPageSize(size));
    var pagetext = pagebreaker.splitPage();
    handlestate(pagetext, 0);
  }

  ///初始化加载
  void handlestate(List<YDPage> ydpage, type) {
    if (config.isSinglePage == 1) {
      ydpage.asMap().keys.map((e) {
        chapaterpage.add(Obx(() => DisplayPage(
              13,
              ydpage[e],
              chapterIndex: 0,
              currPage: currentpageindex.value,
              maxPage: ydpage.length,
              // viewPageIndex: chapaterindex +e,
            )));
      }).toList();
      pages.add({pageindex: chapaterpage.length - 1});
      ydpages.add({pageindex: (ydpage.length).ceil()});
      chapaters.add(pageindex);
    } else {
      for (var i = 0; i < (ydpage.length / 2).ceil(); i++) {
        int doublepage = i * 2;
        chapaterpage.add(Obx(() => DisplayPage(
              13,
              ydpage[doublepage],
              text2: doublepage > ydpage.length - 2
                  ? null
                  : ydpage[doublepage + 1],
              chapterIndex: 0,
              currPage: currentpageindex.value,
              maxPage: (ydpage.length / 2).ceil(),
              // viewPageIndex: chapaterindex +doublepage,
            )));
      }
      pages.add({pageindex: chapaterpage.length - 1});
      ydpages.add({pageindex: ydpage.length});
      chapaters.add(pageindex);
      pageviewcontroller.jumpToPage(0);
    }
  }

  initcode({required List<EpubChapter> p}) {
    //取缓存中的书，看是哪一个章节 哪一个页面 然后加载数据，如果没有就默认0开始    加载
    pageindex; //这个页面index 记得记录 都他妈得记录
    ebookchaps = p;

    ebookchaps.map((e) {
      itemschatgpt.add(e.Title!);
    }).toList();

    var content = regCode(ebookchaps[1].HtmlContent!);
    var pagebreaker = PageBreaker(
        generateContentTextSpan(content),
        generateTitleTextSpan(ebookchaps[1].Title!),
        generateTextPageSize(size));
    var splitPage = pagebreaker.splitPage();

    currentindex = splitPage.length;
    handlestate(splitPage, 0);
  }

  ///单双页切换
  onenumberPagechange() {
    opage.value = !opage.value;
    opage.value ? config.isSinglePage = 1 : config.isSinglePage = 2; //1是单页，而是双页
    onLoadChapter();
  }

  closeAppbar() {
    _topUIopen = true;
    topUIisopen = true;
    dh = true;
    _bottomUIopen = true;
    bottomUIisopen = true;
    initstate(context);
    //退出释放逻辑
    currentindex = 0;
    chapaterindex = 1;
    currentpageindex.value = 0;

    //释放资源
    chapaterpage.clear();
    pages.clear();
    ydpages.clear();
    ebookchaps.clear();

    itemschatgpt.clear();
  }

  setAnimation(ob, context) {
    topUIanimationController = ob;
    bottomUIanimationController = ob;
  }

  initstate(context) {
    showtopUI(context);
    showbottomUI(context);
  }

  showtopUI(context) {
    if (_topUIopen == false) {
      _topUIopen = true;
      topUIisopen = true;
      dh = true;
      show(
          context: context,
          animationController: topUIanimationController,
          tab: readui.top);
    } else {
      topUIisopen == true
          ? topUIanimationController.animateTo(0)
          : topUIanimationController.forward();

      topUIisopen = !topUIisopen;
    }
  }

  showLeftUI(context) {
    if (_leftUIopen == false) {
      _leftUIopen = true;
      leftUIisopen = true;
      show(
          context: context,
          animationController: leftUIanimationController,
          tab: readui.LEFT);
    } else {
      leftUIisopen == true
          ? leftUIanimationController.animateTo(0)
          : leftUIanimationController.forward();

      leftUIisopen = !leftUIisopen;
    }
  }

  showbottomUI(context) {
    if (_bottomUIopen == false) {
      _bottomUIopen = true;
      bottomUIisopen = true;
      show(
          context: context,
          animationController: bottomUIanimationController,
          tab: readui.bottom);
    } else {
      bottomUIisopen == true
          ? bottomUIanimationController.animateTo(0)
          : bottomUIanimationController.forward();
      bottomUIisopen = !bottomUIisopen;
    }
  }

  void show(
      {required BuildContext context,
      required animationController,
      required tab}) {
    switch (tab) {
      case readui.top:
        topUIoverlayEntry = OverlayEntry(builder: (context) {
          return AnimationsPY(
            frame: AppBar(
              centerTitle: true,
              leading: IconButton(
                  onPressed: () {
                    Get.back();
                  },
                  icon: const Icon(Icons.chevron_left)),
              title: Obx(
                () => Text(title.value),
              ),
              actions: [
                IconButton(
                    onPressed: () {
                      onenumberPagechange(); //单双页切换
                    },
                    icon: Obx(() => Icon(opage.value
                        ? Icons.library_books
                        : Icons.chrome_reader_mode))),
                IconButton(onPressed: () {}, icon: const Icon(Icons.headset))
              ],
            ),
            animationController: animationController,
            tab: tab,
          );
        });
        Overlay.of(context)?.insert(topUIoverlayEntry);
        break;
      case readui.bottom:
        bottomUIoverlayEntry = OverlayEntry(builder: (context) {
          return AnimationsPY(
            frame: AppBar(
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  IconButton(
                      onPressed: () {
                        showLeftUI(context);
                      },
                      icon: const Icon(Icons.format_align_left_outlined)),
                  IconButton(
                      onPressed: () {},
                      icon: const Icon(Icons.edit_attributes_outlined)),
                  IconButton(
                      onPressed: () {},
                      icon: const Icon(Icons.brightness_5_outlined)),
                  IconButton(
                      onPressed: () {},
                      icon: const Icon(Icons.translate_outlined)),
                ],
              ),
            ),
            animationController: animationController,
            tab: tab,
          );
        });
        Overlay.of(context)?.insert(
          bottomUIoverlayEntry,
        );
        break;
      case readui.LEFT:
        leftUIoverlayEntry = OverlayEntry(builder: (context) {
          return AnimationsPY(
            frame: ListView.separated(
              itemCount: itemschatgpt.length,
              separatorBuilder: (BuildContext context, int index) => Divider(),
              itemBuilder: (BuildContext context, int index) {
                return InkWell(
                    onTap: () {
                      chapaterindex = 0; //
                      pageindex = index; //这个才是章节index
                      currentindex = 0; //现行选中页 index
                      currentpageindex.value = 0;
                      //初始化大小
                      chapaters.clear();
                      chapaterpage.clear();
                      pages.clear();
                      ydpages.clear();

                      var content = regCode(ebookchaps[index].HtmlContent!);
                      var pagebreaker = PageBreaker(
                          generateContentTextSpan(content),
                          generateTitleTextSpan(ebookchaps[index].Title!),
                          generateTextPageSize(size));
                      var splitPage = pagebreaker.splitPage();

                      currentindex = splitPage.length;
                      handlestate(splitPage, 0);
                    },
                    child: ListTile(
                      title: Text(itemschatgpt[index]),
                    ));
              },
            ),
            animationController: animationController,
            tab: tab,
          );
        });
        Overlay.of(context)?.insert(
          leftUIoverlayEntry,
        );
        break;
      default:
    }

    //延时两秒，移除 OverlayEntry
    //  Future.delayed(Duration(seconds: 20)).then((value) {
    //   overlayEntry.remove();
    // });
  }
}
